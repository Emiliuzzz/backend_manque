import django_filters as df
from .models import Propiedad

class PropiedadFilter(df.FilterSet):
    precio_min = df.NumberFilter(field_name="precio", lookup_expr="gte")
    precio_max = df.NumberFilter(field_name="precio", lookup_expr="lte")
    dormitorios = df.NumberFilter(field_name="dormitorios", lookup_expr="gte")
    banos = df.NumberFilter(field_name="banos", lookup_expr="gte")
    comuna = df.CharFilter(field_name="comuna__nombre", lookup_expr="icontains")
    tipo_operacion = df.CharFilter(field_name="tipo_operacion", lookup_expr="iexact")
    estado = df.CharFilter(field_name="estado", lookup_expr="iexact")

    class Meta:
        model = Propiedad
        fields = ["tipo", "tipo_operacion", "estado"]
