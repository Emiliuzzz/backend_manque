#from rest_framework import routers
#from .api import 


from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

from .views import *      


router = DefaultRouter()

# Rutas API
# Catálogos
router.register(r'propietarios', PropietarioViewSet, basename='propietario')
router.register(r'direcciones', PropietarioDireccionViewSet, basename='direccion-propietario')
router.register(r'regiones', RegionViewSet, basename='region')
router.register(r'comunas', ComunaViewSet, basename='comuna')
router.register(r'interesados', InteresadoViewSet, basename='interesado')

# Negocio
router.register(r'visitas', VisitaViewSet, basename='visita')
router.register(r'reservas', ReservaViewSet, basename='reserva')
router.register(r'contratos', ContratoViewSet, basename='contrato')
router.register(r'pagos', PagoViewSet, basename='pago')

# Archivos
router.register(r'propiedad-fotos', PropiedadFotoViewSet, basename='propiedad-foto')
router.register(r'propiedad-documentos', PropiedadDocumentoViewSet, basename='propiedad-documento')

router.register(r'cuotas', CuotaContratoViewSet, basename='cuota')
router.register(r'notificaciones', NotificacionViewSet, basename='notificacion')

urlpatterns = [
    path('', views.index),
    path('about/', views.about),
    path('hello/', views.hello),
    path('propietario/', views.propietario),
    path('propiedad/<int:id>/', views.propiedad),

    # API base
    path('api/', include(router.urls)),
]


'''
urlpatterns = [
    path('', views.index),
    path('about/', views.about),
    path('hello/', views.hello),
    path('propietario/', views.propietario),
    path('propiedad/<int:id>', views.propiedad),
    
]
'''