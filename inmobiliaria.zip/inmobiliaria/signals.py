from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver
from .models import PropiedadFoto, PropiedadDocumento, Contrato, Comision, Reserva, Visita, Notificacion, CuotaContrato

# Fotos de la propiedad
@receiver(post_delete, sender=PropiedadFoto)
def eliminar_archivo_foto(sender, instance, **kwargs):
    if instance.foto:
        instance.foto.delete(False)

# Tipo de documentos
@receiver(post_delete, sender=PropiedadDocumento)
def eliminar_archivo_documento(sender, instance, **kwargs):
    if instance.archivo:
        instance.archivo.delete(False)

# Comisión contrato
@receiver(post_save, sender=Contrato)
def asegurar_comision_contrato(sender, instance: Contrato, created, **kwargs):
    # Crea Comision vacía si no existe (para editar después vía admin o API)
    if created and not hasattr(instance, "comision"):
        Comision.objects.create(contrato=instance)


def _notificar(usuario, titulo, mensaje, tipo="SISTEMA"):
    Notificacion.objects.create(usuario=usuario, titulo=titulo, mensaje=mensaje, tipo=tipo)

@receiver(post_save, sender=Reserva)
def notificar_reserva(sender, instance: Reserva, created, **kwargs):
    if created and instance.activa:
        _notificar(
            instance.creada_por,
            "Reserva creada",
            f"Propiedad '{instance.propiedad.titulo}' reservada hasta {instance.expires_at}.",
            "RESERVA"
        )

@receiver(post_save, sender=Visita)
def notificar_visita(sender, instance: Visita, created, **kwargs):
    if created:
        _notificar(
            None,
            "Visita agendada",
            f"Visita a '{instance.propiedad.titulo}' el {instance.fecha} a las {instance.hora}.",
            "VISITA"
        )

@receiver(post_save, sender=CuotaContrato)
def notificar_cuota_pagada(sender, instance: CuotaContrato, **kwargs):
    if instance.pagada and instance.pago_id:
        _notificar(
            None,
            "Pago registrado",
            f"Pago de cuota del contrato #{instance.contrato_id} por ${instance.monto}.",
            "PAGO"
        )

