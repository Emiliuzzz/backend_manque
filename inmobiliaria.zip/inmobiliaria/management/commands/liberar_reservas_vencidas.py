from django.core.management.base import BaseCommand
from django.utils import timezone
from inmobiliaria.models import Reserva, Propiedad, Contrato

class Command(BaseCommand):
    help = "Libera propiedades con reservas vencidas"

    def handle(self, *args, **kwargs):
        ahora = timezone.now()
        vencidas = Reserva.objects.filter(activa=True, expires_at__lt=ahora)

        for r in vencidas:
            Reserva.objects.filter(pk=r.pk).update(activa=False)


            # Si no hay otra reserva o contrato, liberar propiedad
            tiene_otra = Reserva.objects.filter(propiedad=r.propiedad, activa=True).exists()
            contrato = Contrato.objects.filter(propiedad=r.propiedad, vigente=True).exists()
            if not tiene_otra and not contrato:
                r.propiedad.estado = "disponible"
                r.propiedad.save(update_fields=["estado"])

        self.stdout.write(self.style.SUCCESS(f"{vencidas.count()} reservas vencidas liberadas."))
