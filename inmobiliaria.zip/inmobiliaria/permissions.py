from rest_framework.permissions import BasePermission, SAFE_METHODS

class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        #return bool(request.user and request.user.is_authenticated and getattr(request.user, "rol", "") == "ADMIN")
        return bool(request.user and request.user.is_authenticated)
class IsAdminOrAsesor(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated)

class ReadOnlyOrAdminAsesor(BasePermission):
    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True
        return bool(request.user and request.user.is_authenticated)
